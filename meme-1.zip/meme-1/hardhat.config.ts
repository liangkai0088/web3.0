require("@nomicfoundation/hardhat-toolbox");

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.28",
    networks: {
        sepolia: {
            url: "https://rpc.sepolia.org",
            accounts: ["a8b3d34977c0346988036a24d868f122b79042403c5ad22c07a6dc9a00c89261"]
        }
    }
};